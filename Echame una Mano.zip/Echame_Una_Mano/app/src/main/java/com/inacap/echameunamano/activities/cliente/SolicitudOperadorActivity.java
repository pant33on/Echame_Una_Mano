package com.inacap.echameunamano.activities.cliente;

import androidx.appcompat.app.AppCompatActivity;
import com.inacap.echameunamano.R;
import android.os.Bundle;

public class SolicitudOperadorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solicitud_operador);
    }
}